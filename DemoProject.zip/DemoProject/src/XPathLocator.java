import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
 
import java.util.List;
 
public class XPathLocator {
 
    // Method to return relative XPath for all input elements inside div with id="bucket"
    public static String relativeXPathForInput(WebDriver driver, String pageUrl) {
        // Navigate to the specified URL
        driver.get(pageUrl);
 
        // Define the relative XPath
        String relativeXPath = "//div[@id='bucket']//input";
 
        // Find the elements to ensure the XPath works (optional for validation)
        List<WebElement> elements = driver.findElements(By.xpath(relativeXPath));
        if (elements.isEmpty()) {
            System.out.println("No elements found using relative XPath");
        } else {
            System.out.println(elements.size() + " elements found using relative XPath");
        }
 
        // Return the relative XPath
        return relativeXPath;
    }
 
    // Method to return absolute XPath for all input elements inside div with id="bucket"
    public static String absoluteXPathForInput(WebDriver driver, String pageUrl) {
        // Navigate to the specified URL
        driver.get(pageUrl);
 
        // Get the absolute XPath for the first input element as an example
        String absoluteXPath = null;
 
        // Locate the first input element inside the div with id="bucket"
        WebElement firstInput = driver.findElement(By.xpath("//div[@id='bucket']//input"));
        System.out.println("first input is " + firstInput);
        //WebElement firstInput= driver.findElement(By.cssSelector("#bucket input:first-of-type"));
        if (firstInput != null) {
            // Generate the absolute XPath dynamically
            String elementPath = (String) ((org.openqa.selenium.JavascriptExecutor) driver)
                    .executeScript(
                            "function absoluteXPath(element) {" +
                                    "var comp, comps = [];" +
                                    "var parent = null;" +
                                    "var xpath = '';" +
                                    "var getPos = function(element) {" +
                                    "var position = 1, curNode;" +
                                    "if (element.nodeType == Node.ATTRIBUTE_NODE) {" +
                                    "return null;" +
                                    "}" +
                                    "for (curNode = element.previousSibling; curNode; curNode = curNode.previousSibling) {" +
                                    "if (curNode.nodeName == element.nodeName) {" +
                                    "++position;" +
                                    "}" +
                                    "}" +
                                    "return position;" +
                                    "};" +
                                    "if (element instanceof Document) {" +
                                    "return '/';" +
                                    "}" +
                                    "for (; element && !(element instanceof Document); element = element.nodeType == Node.ATTRIBUTE_NODE ? element.ownerElement : element.parentNode) {" +
                                    "comp = comps[comps.length] = {};" +
                                    "switch (element.nodeType) {" +
                                    "case Node.TEXT_NODE:" +
"comp.name = 'text()';" +
                                    "break;" +
                                    "case Node.ATTRIBUTE_NODE:" +
"comp.name = '@' + element.nodeName;" +
                                    "break;" +
                                    "case Node.ELEMENT_NODE:" +
"comp.name = element.nodeName;" +
                                    "break;" +
                                    "}" +
                                    "comp.position = getPos(element);" +
                                    "}" +
                                    "for (var i = comps.length - 1; i >= 0; i--) {" +
                                    "comp = comps[i];" +
"xpath += '/' + comp.name.toLowerCase();" +
                                    "if (comp.position !== null) {" +
                                    "xpath += '[' + comp.position + ']';" +
                                    "}" +
                                    "}" +
                                    "return xpath;" +
                                    "}" +
                                    "return absoluteXPath(arguments[0]);",
                            firstInput);
 
            absoluteXPath = elementPath;
        }
 
        // Return the absolute XPath
        return absoluteXPath;
    }
}