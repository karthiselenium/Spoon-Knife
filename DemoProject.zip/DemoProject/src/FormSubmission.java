

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class FormSubmission {

    public static void fillForm(WebDriver driver, String pageUrl) {
        // fill form code goes here
        driver.get(pageUrl);
        WebElement firstNameField = driver.findElement(By.name("first_name"));
        firstNameField.sendKeys("Fizz");
        WebElement lastNameField = driver.findElement(By.name("last_name"));
        lastNameField.sendKeys("Buzz");
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.sendKeys("fizz_buzz@hackerrank.com");
        WebElement passwordField = driver.findElement(By.name("password"));
        passwordField.sendKeys("fizz_buzz@Hrw");
        WebElement confirmPasswordField = driver.findElement(By.name("confirm_password"));
        confirmPasswordField.sendKeys("c_fizz_buzz@Hrw");
    }

    public static void submitForm(WebDriver driver) {
        // Assume this method is called only after calling fillForm(driver,url) method
        WebElement submitButton = driver.findElement(By.xpath("//button[text()='Registar']"));
        submitButton.click();
    }
}