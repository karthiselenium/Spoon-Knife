
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
 
import java.util.ArrayList;
import java.util.List;
 
public class VulnerabilitiesScraper {
 
    // Method to scrape all vulnerabilities for a specific WordPress version
    public static List<String> scrapeVulnerabilitiesOf(WebDriver driver, String vulnPageUrl, String wpVersion) {
        List<String> vulnerabilities = new ArrayList<>();
 
        try {
            // Navigate to the vulnerabilities page
            driver.get(vulnPageUrl);
 
            // Locate all rows in the table
            List<WebElement> rows = driver.findElements(By.xpath("//table/tbody/tr"));
 
            // Iterate through each row
            for (WebElement row : rows) {
                // Find the WordPress version cell
                String version = row.findElement(By.xpath("./td[last()]")).getText();
 
                // Check if the version matches the given wpVersion
                if (version.equals(wpVersion)) {
                    // Get the CVE ID (first cell)
                    String cveId = row.findElement(By.xpath("./td[1]")).getText();
                    vulnerabilities.add(cveId);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
 
        return vulnerabilities;
    }
 
    // Method to find the CVE ID of the highest-scored vulnerability for a specific WordPress version
    public static String topVulnerabilityOf(WebDriver driver, String vulnPageUrl, String wpVersion) {
        String highestScoredCve = null;
        double highestScore = -1.0;
 
        try {
            // Navigate to the vulnerabilities page
            driver.get(vulnPageUrl);
 
            // Locate all rows in the table
            List<WebElement> rows = driver.findElements(By.xpath("//table/tbody/tr"));
           
            for (WebElement element: rows){
                logger.info(element.getText());
         }
 
            // Iterate through each row
            for (WebElement row : rows) {
                // Find the WordPress version cell
                String version = row.findElement(By.xpath("./td[last()]")).getText();
                
                System.out.println("print rows" + version);
 
                // Check if the version matches the given wpVersion
                if (version.equals(wpVersion)) {
                    // Get the score (4th cell)
                    double score = Double.parseDouble(row.findElement(By.xpath("./td[4]")).getText());
 
                    // Update highest score and CVE ID if a new highest is found
                    if (score > highestScore) {
                        highestScore = score;
                        highestScoredCve = row.findElement(By.xpath("./td[1]")).getText();
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
 
        return highestScoredCve;
    }
}