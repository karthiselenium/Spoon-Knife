import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
 
public class TestXPathLocator {
    public static void main(String[] args) {
        WebDriver driver = new HtmlUnitDriver();
 
        // Example URL (replace with actual URL)
        String url = "http://example.com/form";
 
        // Get relative XPath
       String relativeXPath = XPathLocator.relativeXPathForInput(driver, url);
        System.out.println("Relative XPath: " + relativeXPath);
 
        // Get absolute XPath
        String absoluteXPath = XPathLocator.absoluteXPathForInput(driver, url);
        System.out.println("Absolute XPath: " + absoluteXPath);
 
        driver.quit();
    }
}